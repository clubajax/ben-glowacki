var property=window.property;
document.write('<script language="javascript" src="http://widgets.fccinteractive.com/tracking/data/'+property+'/article/mostRead.html"></script>'); 
